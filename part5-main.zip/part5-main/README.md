# part5
This repository contains the exercises of part-5
